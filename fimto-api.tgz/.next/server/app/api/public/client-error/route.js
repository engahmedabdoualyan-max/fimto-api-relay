var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/client-error/route.js")
R.c("server/chunks/[root-of-the-server]__0wg50vz._.js")
R.c("server/chunks/[root-of-the-server]__0lfb_29._.js")
R.c("server/chunks/[root-of-the-server]__19vrhl-._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_public_client-error_route_actions_02b-a9u.js")
R.m(93138)
module.exports=R.m(93138).exports
