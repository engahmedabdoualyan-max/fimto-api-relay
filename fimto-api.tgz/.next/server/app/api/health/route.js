var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]_firebase-admin_1cphyqk._.js")
R.c("server/chunks/[root-of-the-server]__0gb-e-0._.js")
R.c("server/chunks/[root-of-the-server]__19vrhl-._.js")
R.c("server/chunks/_1ta9fr4._.js")
R.c("server/chunks/node_modules_drizzle-orm_0c8-262._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkb.js")
R.m(43007)
module.exports=R.m(43007).exports
