module.exports=[41235,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_optimize_route_actions_00ogpl0.js.map