module.exports=[19723,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_%5BtripId%5D_signature_route_actions_0dnsfb1.js.map