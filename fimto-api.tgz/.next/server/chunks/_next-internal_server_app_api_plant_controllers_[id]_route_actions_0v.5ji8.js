module.exports=[81821,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plant_controllers_%5Bid%5D_route_actions_0v.5ji8.js.map