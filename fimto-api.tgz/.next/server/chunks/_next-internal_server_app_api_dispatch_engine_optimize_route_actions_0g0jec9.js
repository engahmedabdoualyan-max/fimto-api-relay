module.exports=[91744,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_engine_optimize_route_actions_0g0jec9.js.map