module.exports=[90880,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_competitors_%5Bid%5D_route_actions_014m-hd.js.map