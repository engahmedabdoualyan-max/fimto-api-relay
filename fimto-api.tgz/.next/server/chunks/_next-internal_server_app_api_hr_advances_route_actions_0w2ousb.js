module.exports=[73739,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_advances_route_actions_0w2ousb.js.map