module.exports=[3970,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_batching_start_route_actions_0.de-m~.js.map