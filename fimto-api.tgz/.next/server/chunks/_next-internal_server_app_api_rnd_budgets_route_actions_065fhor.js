module.exports=[54119,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_budgets_route_actions_065fhor.js.map