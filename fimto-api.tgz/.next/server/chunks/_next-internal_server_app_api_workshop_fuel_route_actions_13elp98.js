module.exports=[43808,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workshop_fuel_route_actions_13elp98.js.map