module.exports=[62922,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_attendance_ping_route_actions_1043is5.js.map