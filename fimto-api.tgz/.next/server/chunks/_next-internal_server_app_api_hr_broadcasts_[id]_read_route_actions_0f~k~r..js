module.exports=[41450,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_broadcasts_%5Bid%5D_read_route_actions_0f~k~r..js.map