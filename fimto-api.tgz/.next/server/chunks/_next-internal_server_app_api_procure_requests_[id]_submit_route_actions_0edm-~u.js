module.exports=[36543,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_submit_route_actions_0edm-~u.js.map