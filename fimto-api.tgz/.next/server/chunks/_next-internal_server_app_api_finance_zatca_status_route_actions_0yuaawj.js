module.exports=[86361,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_zatca_status_route_actions_0yuaawj.js.map