module.exports=[20839,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_violations_%5Bid%5D_pay_route_actions_0t_rz44.js.map