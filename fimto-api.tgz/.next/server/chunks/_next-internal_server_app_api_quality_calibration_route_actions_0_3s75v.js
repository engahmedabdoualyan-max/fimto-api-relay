module.exports=[1519,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_quality_calibration_route_actions_0_3s75v.js.map