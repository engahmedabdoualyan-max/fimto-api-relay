module.exports=[99115,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sustainability_summary_route_actions_0.vn64n.js.map