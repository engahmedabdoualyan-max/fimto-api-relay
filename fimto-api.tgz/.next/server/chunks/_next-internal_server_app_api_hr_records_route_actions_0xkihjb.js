module.exports=[16381,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_records_route_actions_0xkihjb.js.map