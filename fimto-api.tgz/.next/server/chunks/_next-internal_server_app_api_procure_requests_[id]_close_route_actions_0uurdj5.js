module.exports=[71966,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_close_route_actions_0uurdj5.js.map