module.exports=[92658,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_weekly_route_actions_12siokc.js.map