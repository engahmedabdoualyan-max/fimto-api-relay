module.exports=[9968,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_plans_%5BplanId%5D_route_actions_0eneqpa.js.map