module.exports=[80452,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_plans_%5BplanId%5D_route_actions_0o20vct.js.map