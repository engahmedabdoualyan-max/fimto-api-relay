module.exports=[86929,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_invoices_%5Bid%5D_route_actions_0_78l46.js.map