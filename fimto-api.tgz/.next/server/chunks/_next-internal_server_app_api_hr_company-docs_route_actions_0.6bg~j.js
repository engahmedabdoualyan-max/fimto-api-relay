module.exports=[87588,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_company-docs_route_actions_0.6bg~j.js.map