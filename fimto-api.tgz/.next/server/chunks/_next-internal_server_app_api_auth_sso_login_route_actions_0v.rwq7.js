module.exports=[26857,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_sso_login_route_actions_0v.rwq7.js.map