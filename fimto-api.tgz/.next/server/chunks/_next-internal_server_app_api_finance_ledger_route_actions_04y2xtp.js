module.exports=[76838,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_ledger_route_actions_04y2xtp.js.map