module.exports=[66763,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_approve_route_actions_0.nrd0r.js.map