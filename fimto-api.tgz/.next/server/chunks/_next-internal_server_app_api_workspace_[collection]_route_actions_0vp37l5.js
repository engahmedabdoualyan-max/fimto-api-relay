module.exports=[90635,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workspace_%5Bcollection%5D_route_actions_0vp37l5.js.map