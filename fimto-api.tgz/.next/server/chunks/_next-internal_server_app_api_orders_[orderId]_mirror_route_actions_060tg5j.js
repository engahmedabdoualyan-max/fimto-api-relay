module.exports=[49442,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orders_%5BorderId%5D_mirror_route_actions_060tg5j.js.map