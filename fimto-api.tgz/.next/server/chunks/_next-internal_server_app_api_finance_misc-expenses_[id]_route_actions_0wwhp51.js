module.exports=[5779,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_misc-expenses_%5Bid%5D_route_actions_0wwhp51.js.map