module.exports=[76265,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sustainability_factors_route_actions_0r1_f0p.js.map