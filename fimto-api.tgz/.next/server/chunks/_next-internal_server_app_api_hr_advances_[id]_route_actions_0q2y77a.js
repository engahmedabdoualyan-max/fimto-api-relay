module.exports=[63072,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_advances_%5Bid%5D_route_actions_0q2y77a.js.map