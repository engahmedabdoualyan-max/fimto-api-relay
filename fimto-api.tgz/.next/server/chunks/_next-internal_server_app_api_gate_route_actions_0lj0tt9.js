module.exports=[80255,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gate_route_actions_0lj0tt9.js.map