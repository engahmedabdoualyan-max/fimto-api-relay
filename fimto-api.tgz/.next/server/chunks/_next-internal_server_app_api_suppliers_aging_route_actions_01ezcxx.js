module.exports=[83879,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_aging_route_actions_01ezcxx.js.map