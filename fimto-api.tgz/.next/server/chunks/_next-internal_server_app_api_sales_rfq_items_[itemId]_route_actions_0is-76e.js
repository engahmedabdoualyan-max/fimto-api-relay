module.exports=[86900,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_rfq_items_%5BitemId%5D_route_actions_0is-76e.js.map