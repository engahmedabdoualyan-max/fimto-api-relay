module.exports=[42636,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_petty-cash_route_actions_0ds~wo4.js.map