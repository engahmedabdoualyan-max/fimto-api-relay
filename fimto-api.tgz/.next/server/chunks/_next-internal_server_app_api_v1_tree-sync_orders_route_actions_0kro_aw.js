module.exports=[74716,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tree-sync_orders_route_actions_0kro_aw.js.map