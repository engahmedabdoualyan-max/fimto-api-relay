module.exports=[39483,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_vehicles_route_actions_0ul3mhf.js.map