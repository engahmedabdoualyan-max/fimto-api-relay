module.exports=[12928,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_ledger_entries_route_actions_0820g.n.js.map