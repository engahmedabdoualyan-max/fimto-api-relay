module.exports=[11890,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workspace_summary_route_actions_0f1i4s~.js.map