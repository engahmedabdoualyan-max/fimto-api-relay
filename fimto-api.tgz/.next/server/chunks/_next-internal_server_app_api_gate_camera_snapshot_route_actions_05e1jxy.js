module.exports=[92059,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gate_camera_snapshot_route_actions_05e1jxy.js.map