module.exports=[53066,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_broadcasts_%5Bid%5D_reads_route_actions_0tm63w5.js.map