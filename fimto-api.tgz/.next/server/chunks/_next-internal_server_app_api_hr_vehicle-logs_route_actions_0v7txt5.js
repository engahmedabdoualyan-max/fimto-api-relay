module.exports=[14447,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_vehicle-logs_route_actions_0v7txt5.js.map