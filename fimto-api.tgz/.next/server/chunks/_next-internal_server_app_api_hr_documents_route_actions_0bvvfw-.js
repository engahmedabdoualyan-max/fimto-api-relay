module.exports=[87653,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_documents_route_actions_0bvvfw-.js.map