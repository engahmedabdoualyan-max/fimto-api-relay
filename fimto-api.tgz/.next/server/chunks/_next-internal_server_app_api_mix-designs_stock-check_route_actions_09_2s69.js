module.exports=[77016,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mix-designs_stock-check_route_actions_09_2s69.js.map