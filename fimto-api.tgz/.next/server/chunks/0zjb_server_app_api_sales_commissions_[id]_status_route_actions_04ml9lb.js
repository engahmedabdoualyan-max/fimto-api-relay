module.exports=[23601,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_sales_commissions_%5Bid%5D_status_route_actions_04ml9lb.js.map