module.exports=[78106,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_push_register_route_actions_12a0_93.js.map