module.exports=[73655,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_cost-margin_route_actions_0.~_~lr.js.map