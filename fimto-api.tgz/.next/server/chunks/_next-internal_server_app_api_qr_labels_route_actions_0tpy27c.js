module.exports=[63696,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_qr_labels_route_actions_0tpy27c.js.map