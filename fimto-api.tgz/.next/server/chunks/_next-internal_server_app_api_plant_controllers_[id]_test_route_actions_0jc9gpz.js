module.exports=[33136,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plant_controllers_%5Bid%5D_test_route_actions_0jc9gpz.js.map