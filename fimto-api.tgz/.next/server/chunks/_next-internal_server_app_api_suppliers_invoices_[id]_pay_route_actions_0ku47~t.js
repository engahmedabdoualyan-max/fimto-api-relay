module.exports=[40876,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_invoices_%5Bid%5D_pay_route_actions_0ku47~t.js.map