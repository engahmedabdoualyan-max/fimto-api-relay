module.exports=[25528,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workshop_history_route_actions_01mdruj.js.map