module.exports=[69987,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_leave-balances_route_actions_0my.r1v.js.map