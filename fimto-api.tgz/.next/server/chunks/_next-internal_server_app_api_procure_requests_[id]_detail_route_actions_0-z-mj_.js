module.exports=[79793,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_detail_route_actions_0-z-mj_.js.map