module.exports=[3139,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orders_by-ref_route_actions_013qojm.js.map