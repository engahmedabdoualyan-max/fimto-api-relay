module.exports=[6963,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_route_actions_10x31ij.js.map