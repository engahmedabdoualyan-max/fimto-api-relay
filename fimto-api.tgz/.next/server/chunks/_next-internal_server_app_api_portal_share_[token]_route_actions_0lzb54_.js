module.exports=[66957,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_share_%5Btoken%5D_route_actions_0lzb54_.js.map