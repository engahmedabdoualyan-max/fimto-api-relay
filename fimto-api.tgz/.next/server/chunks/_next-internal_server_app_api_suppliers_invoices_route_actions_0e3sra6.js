module.exports=[59807,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_invoices_route_actions_0e3sra6.js.map