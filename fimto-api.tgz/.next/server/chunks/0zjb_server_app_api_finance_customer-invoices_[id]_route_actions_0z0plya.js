module.exports=[19077,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_finance_customer-invoices_%5Bid%5D_route_actions_0z0plya.js.map