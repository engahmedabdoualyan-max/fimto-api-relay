module.exports=[4936,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_budgets_%5BbudgetId%5D_route_actions_0h4y5.7.js.map