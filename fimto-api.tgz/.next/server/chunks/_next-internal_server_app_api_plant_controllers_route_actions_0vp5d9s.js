module.exports=[60418,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plant_controllers_route_actions_0vp5d9s.js.map