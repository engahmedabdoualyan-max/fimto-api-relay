module.exports=[88311,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_integrations_accounting_%5Bid%5D_logs_route_actions_0vy9dr..js.map