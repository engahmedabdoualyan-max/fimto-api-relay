module.exports=[48235,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_rfq_route_actions_0igd_hw.js.map