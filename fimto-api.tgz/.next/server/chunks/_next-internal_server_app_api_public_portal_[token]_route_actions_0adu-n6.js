module.exports=[64556,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_public_portal_%5Btoken%5D_route_actions_0adu-n6.js.map