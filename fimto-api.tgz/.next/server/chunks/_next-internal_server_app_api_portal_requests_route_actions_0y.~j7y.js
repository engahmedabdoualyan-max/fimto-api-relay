module.exports=[80771,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_requests_route_actions_0y.~j7y.js.map