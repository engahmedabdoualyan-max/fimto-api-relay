module.exports=[76658,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_investigations_%5Bid%5D_close_route_actions_0a---ih.js.map