module.exports=[43989,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_issues_%5BissueId%5D_route_actions_0se_w4o.js.map