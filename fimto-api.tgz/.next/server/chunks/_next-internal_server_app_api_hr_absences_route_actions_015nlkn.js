module.exports=[30329,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_absences_route_actions_015nlkn.js.map