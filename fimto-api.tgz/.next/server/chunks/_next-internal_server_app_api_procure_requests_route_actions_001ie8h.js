module.exports=[64236,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_route_actions_001ie8h.js.map