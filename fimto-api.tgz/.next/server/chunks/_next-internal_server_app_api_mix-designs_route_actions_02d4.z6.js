module.exports=[67156,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mix-designs_route_actions_02d4.z6.js.map