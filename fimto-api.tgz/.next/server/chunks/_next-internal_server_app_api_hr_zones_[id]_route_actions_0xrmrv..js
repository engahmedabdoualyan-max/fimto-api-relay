module.exports=[10741,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_zones_%5Bid%5D_route_actions_0xrmrv..js.map