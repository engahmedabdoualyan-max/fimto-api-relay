module.exports=[77729,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clients_risk_route_actions_0xvyd4r.js.map