module.exports=[53893,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reports_share_%5BreportId%5D_route_actions_0i_qf62.js.map