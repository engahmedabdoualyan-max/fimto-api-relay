module.exports=[20070,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_verify-ticket-qr_route_actions_11bz-r4.js.map