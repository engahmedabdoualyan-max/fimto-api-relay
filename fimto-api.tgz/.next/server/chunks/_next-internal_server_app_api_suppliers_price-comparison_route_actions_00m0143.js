module.exports=[52646,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_price-comparison_route_actions_00m0143.js.map