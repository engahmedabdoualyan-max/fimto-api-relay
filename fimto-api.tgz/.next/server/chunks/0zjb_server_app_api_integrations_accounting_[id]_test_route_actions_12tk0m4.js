module.exports=[5472,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_integrations_accounting_%5Bid%5D_test_route_actions_12tk0m4.js.map