module.exports=[1590,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fleet_devices_%5BdeviceId%5D_route_actions_1246e7t.js.map