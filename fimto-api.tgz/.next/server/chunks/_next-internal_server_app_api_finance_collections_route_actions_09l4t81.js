module.exports=[15855,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_collections_route_actions_09l4t81.js.map