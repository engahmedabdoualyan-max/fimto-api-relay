module.exports=[7784,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_vehicles_%5Bid%5D_renewals_route_actions_0peor.1.js.map