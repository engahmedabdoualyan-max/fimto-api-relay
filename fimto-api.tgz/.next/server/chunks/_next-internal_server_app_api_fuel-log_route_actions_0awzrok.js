module.exports=[49321,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fuel-log_route_actions_0awzrok.js.map