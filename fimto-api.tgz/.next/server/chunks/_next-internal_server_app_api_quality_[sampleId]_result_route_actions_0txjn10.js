module.exports=[1595,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_quality_%5BsampleId%5D_result_route_actions_0txjn10.js.map