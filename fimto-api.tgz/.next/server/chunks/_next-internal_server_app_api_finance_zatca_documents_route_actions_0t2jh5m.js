module.exports=[27251,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_zatca_documents_route_actions_0t2jh5m.js.map