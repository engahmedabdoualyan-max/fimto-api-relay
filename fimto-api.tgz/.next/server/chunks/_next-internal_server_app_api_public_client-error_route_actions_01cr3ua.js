module.exports=[59662,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_public_client-error_route_actions_01cr3ua.js.map