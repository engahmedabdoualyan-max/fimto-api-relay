module.exports=[50308,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_sustainability_order_%5BorderId%5D_route_actions_13lx~sf.js.map