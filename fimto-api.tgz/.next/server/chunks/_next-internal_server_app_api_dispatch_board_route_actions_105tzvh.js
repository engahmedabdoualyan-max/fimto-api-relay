module.exports=[40393,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dispatch_board_route_actions_105tzvh.js.map