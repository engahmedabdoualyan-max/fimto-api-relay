module.exports=[98064,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_driver-bonus_route_actions_0kyx0u1.js.map