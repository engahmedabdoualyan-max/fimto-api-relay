module.exports=[47352,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_blocks_today_route_actions_0sscjsf.js.map