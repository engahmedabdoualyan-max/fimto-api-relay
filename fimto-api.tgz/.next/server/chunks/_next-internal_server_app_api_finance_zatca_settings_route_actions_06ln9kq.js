module.exports=[36864,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_zatca_settings_route_actions_06ln9kq.js.map