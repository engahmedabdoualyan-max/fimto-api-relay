module.exports=[19202,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_review_route_actions_0c2kkzj.js.map