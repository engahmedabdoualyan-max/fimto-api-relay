module.exports=[80633,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_plans_route_actions_0azj_61.js.map