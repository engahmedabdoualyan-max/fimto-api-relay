module.exports=[77631,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_products_%5BproductId%5D_route_actions_0-5mv1j.js.map