module.exports=[46978,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_%5BorderId%5D_override_route_actions_0fq59i6.js.map