module.exports=[27166,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_zatca_issue_route_actions_05~y.4q.js.map