module.exports=[62660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_settings_route_actions_12wba5a.js.map