module.exports=[2728,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_requests_route_actions_01-1tzu.js.map