module.exports=[2546,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_route_actions_0rkbmne.js.map