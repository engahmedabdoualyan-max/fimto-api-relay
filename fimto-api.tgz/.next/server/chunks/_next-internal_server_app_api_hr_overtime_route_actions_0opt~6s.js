module.exports=[70540,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_overtime_route_actions_0opt~6s.js.map