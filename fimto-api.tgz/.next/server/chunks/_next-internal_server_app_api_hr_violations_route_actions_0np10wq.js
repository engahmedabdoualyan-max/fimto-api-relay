module.exports=[68757,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_violations_route_actions_0np10wq.js.map