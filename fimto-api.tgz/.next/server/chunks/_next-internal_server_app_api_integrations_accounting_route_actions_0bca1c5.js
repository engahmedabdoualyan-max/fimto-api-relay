module.exports=[99437,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_integrations_accounting_route_actions_0bca1c5.js.map