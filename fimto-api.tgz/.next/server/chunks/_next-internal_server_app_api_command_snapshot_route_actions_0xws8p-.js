module.exports=[90667,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_command_snapshot_route_actions_0xws8p-.js.map