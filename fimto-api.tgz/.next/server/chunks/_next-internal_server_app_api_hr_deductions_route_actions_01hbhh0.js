module.exports=[4320,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_deductions_route_actions_01hbhh0.js.map