module.exports=[88284,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gate_%5Bid%5D_route_actions_0jfie76.js.map