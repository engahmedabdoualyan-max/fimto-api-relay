module.exports=[29019,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_quotes_route_actions_0rndnhy.js.map