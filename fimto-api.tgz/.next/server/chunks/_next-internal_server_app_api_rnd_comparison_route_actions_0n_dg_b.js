module.exports=[36568,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rnd_comparison_route_actions_0n_dg_b.js.map