module.exports=[95757,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_expenses_route_actions_0c62pjx.js.map