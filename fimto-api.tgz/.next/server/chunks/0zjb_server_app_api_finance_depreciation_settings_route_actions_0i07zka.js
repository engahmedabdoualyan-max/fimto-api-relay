module.exports=[87778,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_finance_depreciation_settings_route_actions_0i07zka.js.map