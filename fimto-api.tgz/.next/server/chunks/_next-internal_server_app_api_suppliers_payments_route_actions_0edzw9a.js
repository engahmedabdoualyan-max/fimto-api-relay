module.exports=[81259,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suppliers_payments_route_actions_0edzw9a.js.map