module.exports=[24816,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_sso_providers_route_actions_0d4n6gg.js.map