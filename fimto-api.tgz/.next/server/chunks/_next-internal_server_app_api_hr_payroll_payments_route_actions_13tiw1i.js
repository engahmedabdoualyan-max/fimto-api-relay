module.exports=[74884,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_payroll_payments_route_actions_13tiw1i.js.map