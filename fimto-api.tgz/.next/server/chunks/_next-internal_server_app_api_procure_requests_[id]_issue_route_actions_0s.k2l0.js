module.exports=[92863,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_procure_requests_%5Bid%5D_issue_route_actions_0s.k2l0.js.map