module.exports=[28886,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_commissions_schemes_route_actions_0lmz~c6.js.map