module.exports=[58804,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gate_camera_route_actions_0v-8so6.js.map