module.exports=[49025,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hr_investigations_route_actions_0vekoad.js.map