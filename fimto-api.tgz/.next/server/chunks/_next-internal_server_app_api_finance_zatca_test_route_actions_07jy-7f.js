module.exports=[74082,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_finance_zatca_test_route_actions_07jy-7f.js.map