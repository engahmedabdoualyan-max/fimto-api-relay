globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3tWwKHmNljR3vvm2UJPO-/_buildManifest.js",
    "static/3tWwKHmNljR3vvm2UJPO-/_ssgManifest.js",
    "static/3tWwKHmNljR3vvm2UJPO-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/12aruqaur5huj.js",
    "static/chunks/3q5hirtwweuqh.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/turbopack-2c_queg-wcphr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
