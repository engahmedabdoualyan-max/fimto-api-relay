globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/sweaQdn8b6Z6rWJpgLOZs/_buildManifest.js",
    "static/sweaQdn8b6Z6rWJpgLOZs/_ssgManifest.js",
    "static/sweaQdn8b6Z6rWJpgLOZs/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/12aruqaur5huj.js",
    "static/chunks/3q5hirtwweuqh.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/turbopack-2c_queg-wcphr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
