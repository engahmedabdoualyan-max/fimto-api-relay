globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/QWuRvSG6AMp9nWJfvIaUB/_buildManifest.js",
    "static/QWuRvSG6AMp9nWJfvIaUB/_ssgManifest.js",
    "static/QWuRvSG6AMp9nWJfvIaUB/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/12aruqaur5huj.js",
    "static/chunks/3q5hirtwweuqh.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/turbopack-2c_queg-wcphr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
